from PyQt6.QtWidgets import QWidget, QCheckBox
from PyQt6.QtCore import QRegularExpression, pyqtSignal
from PyQt6.QtGui import QRegularExpressionValidator
from view.ui.Preference_ui import Ui_Preference
from typing import List
from controller.setting import Setting


class WidgetPreference(QWidget):
    savePreference = pyqtSignal()  # Tạo một signal mới

    def __init__(self):
        super(WidgetPreference, self).__init__()
        self.ui = Ui_Preference()
        self.ui.setupUi(self)

        # Set the custom validator for the line edit
        digit_space_validator = DigitSpaceValidator()
        self.ui.lineEdit_dataConfigImportSkipRows.setValidator(
            digit_space_validator)

        self.ui.btnSave.clicked.connect(self.savePreference.emit)

        # Thêm vào hàm init
        self.ui.checkBox_showAbnormalHighlight.setChecked(Setting.OPTS_PLOTCONFIG_SHOW_ABNORMAL)

    def getUI_preference(self):
        dataset_label_rotation = int(self.ui.comboBox_datasetLabelRotation.currentText())
        show_median = self.ui.checkBox_showMedian.isChecked()
        show_cpk = self.ui.checkBox_showCpk.isChecked()
        show_n = self.ui.checkBox_showN.isChecked()
        show_violin = self.ui.checkBox_showViolin.isChecked()
        show_individual = self.ui.checkBox_showIndividual.isChecked()
        use_gradient = self.ui.checkBox_useGradientColors.isChecked()
        median_size = int(self.ui.comboBox_plotConfigMedianFontSize.currentText())
        title_size = int(self.ui.comboBox_plotTitleFontSize.currentText())
        skiprows = self.ui.lineEdit_dataConfigImportSkipRows.text()
        if skiprows == 'None':
            skiprows = None
        else:
            skiprows = skiprows.split(' ')
            skiprows = [int(num) for num in skiprows if num.isnumeric()]
            skiprows = [row for row in skiprows if row >= 0]
            if len(skiprows) == 0:
                skiprows = None

        # Thêm vào hàm get
        plotconfig_showAbnormal = self.ui.checkBox_showAbnormalHighlight.isChecked()
        dataset_label_size = int(self.ui.comboBox_datasetLabelFontSize.currentText())

        return (dataset_label_rotation, show_median, show_cpk, show_n, show_violin, 
                show_individual, use_gradient, median_size, title_size, skiprows, 
                plotconfig_showAbnormal, dataset_label_size)

    def setUI_preference(
        self,
        dataset_label_rotation: int,
        show_median: bool,
        show_cpk: bool,
        show_n: bool,
        show_violin: bool,
        show_individual: bool,
        use_gradient: bool,
        median_fontsize: int,
        title_fontsize: int,
        rowskip: List[int],
        dataset_label_fontsize: int = 5  # Thêm tham số mới với giá trị mặc định
    ) -> None:
        # Data validation
        if type(dataset_label_rotation) != int:
            dataset_label_rotation = 0
        else:
            if not dataset_label_rotation in [0, 45, 90]:
                dataset_label_rotation = 0

        if type(median_fontsize) != int:
            median_fontsize = 4
        else:
            if not median_fontsize in range(2, 10, 1):
                median_fontsize = 4

        if type(title_fontsize) != int:
            title_fontsize = 6
        else:
            if not title_fontsize in range(2, 11):
                title_fontsize = 6

        if rowskip != None:
            rowskip = [num for num in rowskip if type(num) == int]
            rowskip = [num for num in rowskip if num >= 0]
            if len(rowskip) == 0:
                rowskip = None

        # Set UI
        try:
            self.ui.comboBox_datasetLabelRotation.setCurrentText(
                str(dataset_label_rotation))
        except:
            self.ui.comboBox_datasetLabelRotation.setCurrentIndex(0)

        self.ui.checkBox_showMedian.setChecked(show_median)
        self.ui.checkBox_showCpk.setChecked(show_cpk)
        self.ui.checkBox_showN.setChecked(show_n)
        self.ui.checkBox_showViolin.setChecked(show_violin)
        self.ui.checkBox_showIndividual.setChecked(show_individual)
        self.ui.checkBox_useGradientColors.setChecked(use_gradient)

        try:
            self.ui.comboBox_plotConfigMedianFontSize.setCurrentText(
                str(median_fontsize))
        except:
            self.ui.comboBox_plotConfigMedianFontSize.setCurrentIndex(0)

        try:
            self.ui.comboBox_plotTitleFontSize.setCurrentText(str(title_fontsize))
        except:
            self.ui.comboBox_plotTitleFontSize.setCurrentIndex(4)

        if rowskip == None:
            self.ui.lineEdit_dataConfigImportSkipRows.setText('None')
        else:
            self.ui.lineEdit_dataConfigImportSkipRows.setText(
                ' '.join(map(str, rowskip)))

        try:
            self.ui.comboBox_datasetLabelFontSize.setCurrentText(str(dataset_label_fontsize))
        except:
            self.ui.comboBox_datasetLabelFontSize.setCurrentIndex(3)  # Default to 5

        return None


class DigitSpaceValidator(QRegularExpressionValidator):
    """
    Custom validator class to set Validator for Line Edit to only accept digits and space characters
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        # Regular expression to match digits and space characters only
        regex = QRegularExpression("[0-9 ]*")
        self.setRegularExpression(regex)

    def validate(self, input, pos):
        # Use the regular expression validation
        return super().validate(input, pos)
