from __future__ import annotations
from typing import List, Callable
from PyQt6 import QtGui
from PyQt6.QtWidgets import QWidget, QFormLayout, QMessageBox
from view.ui.PlotFigure_ui import Ui_PlotFigure
from controller.setting import Setting
from controller.workstatus import Status
from model.csv_database import CSV_Database
from model.figureconfig import FigureConfig
from util.image_embed_pptx import ImageEmbedPPTX
import numpy as np
import os
from util.boxplot_analyzer import BoxplotAnalyzer

# Thêm các dòng này để cấu hình matplotlib
import matplotlib
matplotlib.use('Agg')  # Thay đổi từ Qt5Agg sang Agg

# Sau đó mới import các module khác
from matplotlib.figure import Figure
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib.pyplot as plt
from matplotlib import ticker
import seaborn as sns
import colorsys


"""
Customize Matplotlib style with rcParams
"""
# CONFIGURE LINE STYLE (Ref LINE of BOX PLOT)
plt.rcParams['lines.linewidth'] = 0.5
plt.rcParams['lines.color'] = 'red'
plt.rcParams['lines.linestyle'] = '--'

# CONFIGURE COLOR OF OUTLIERS
plt.rcParams['boxplot.flierprops.linewidth'] = 0.3
plt.rcParams['boxplot.flierprops.marker'] = 'x'
plt.rcParams['boxplot.flierprops.markersize'] = 2
plt.rcParams['boxplot.flierprops.markeredgewidth'] = 0.3
plt.rcParams['boxplot.flierprops.markerfacecolor'] = 'grey'
plt.rcParams['boxplot.showcaps'] = False
plt.rcParams['boxplot.whiskerprops.linewidth'] = 0.4

# CONFIGURE COLOR OF BOX BODY
plt.rcParams['boxplot.boxprops.linewidth'] = 0.4
plt.rcParams['boxplot.boxprops.color'] = 'black'
plt.rcParams['boxplot.patchartist'] = True
plt.rcParams['patch.facecolor'] = 'lightgray'
plt.rcParams['boxplot.medianprops.color'] = 'black'
plt.rcParams['boxplot.medianprops.linewidth'] = 0.4

# CONFIGURE SUBPLOT TITLE
plt.rcParams['axes.edgecolor'] = 'gray'
plt.rcParams['axes.linewidth'] = 0.3
plt.rcParams['axes.labelpad'] = 4               # space between label and axis
plt.rcParams['axes.titlecolor'] = 'black'       # Set color for subplot title
# plt.rcParams['axes.titleweight'] = 'bold'     # Set font weight for subplot title
# Set font size for subplot title
plt.rcParams['axes.titlesize'] = 8
# pad between axes and title in points
plt.rcParams['axes.titlepad'] = 4
plt.rcParams['axes.grid'] = True
plt.rcParams['polaraxes.grid'] = True
# set boxplot x-axis label color
plt.rcParams['xtick.labelcolor'] = 'black'
# set boxplot x-axis label font size
plt.rcParams['xtick.labelsize'] = 5
plt.rcParams['xtick.bottom'] = False
# distance to major tick label in points
plt.rcParams['xtick.major.pad'] = 0

# set boxplot y-axis label font size
plt.rcParams['ytick.labelsize'] = 5
plt.rcParams['ytick.major.width'] = 0.2         # major tick width in points
plt.rcParams['ytick.major.size'] = 1.5          # major tick width in points

# CONFIGURE BOXPLOT TITLE AND LABEL
plt.rcParams['figure.titlesize'] = '8'
plt.rcParams['figure.autolayout'] = True
plt.rcParams['figure.constrained_layout.h_pad'] = 0.8
plt.rcParams['figure.constrained_layout.w_pad'] = 0.5
plt.rcParams['figure.dpi'] = 200                # fit full-screen viewing
plt.rcParams['font.family'] = 'tahoma'

plt.rcParams['grid.color'] = 'lightgray'        # grid color
plt.rcParams['grid.linestyle'] = 'solid'
plt.rcParams['grid.linewidth'] = 0.1            # in points
# ***************************************************************************
# * SAVING FIGURES                                                          *
# ***************************************************************************
# The default savefig parameters can be different from the display parameters
# e.g., you may want a higher resolution, or to make the figure
# background white
# figure dots per inch or 'figure'
plt.rcParams['savefig.dpi'] = 300
# figure face color when saving
plt.rcParams['savefig.facecolor'] = 'auto'
# figure edge color when saving
plt.rcParams['savefig.edgecolor'] = 'auto'
plt.rcParams['savefig.format'] = 'png'         # {png, ps, pdf, svg}
plt.rcParams['savefig.bbox'] = 'tight'
# whether figures are saved with a transparent background by default
plt.rcParams['savefig.transparent'] = False
# orientation of saved figure, for PostScript output only
plt.rcParams['savefig.orientation'] = 'portrait'

"""
- UI components struture of Plot Figure widget:
- Main widget
    - Tabview object (dtype: QTabview)
        - Tab object (dtype: Qwidget)
            - Layout object (dtype: QFormLayout | QVBoxlayout)
                - Figure object (dtype: figure returned by matplotlib.pyplot.subplot)
                    - Box plot object (dtype: figure returned by matplotlib.pyplot.boxplot)

* Embedding matplotlib figure object to PyQt Widget form
- Make 'figure' = Figure object, returned by matplotlib.pyplot.boxplot() and matplotlib.pyplot.subplots()
- Make canvas = FigureCanvasQTAgg object, returned by FigureCanvasQTAgg(figure)
- Make 'layout' = QFormLayout object, returned by layout.addWidget()
- Make main_widget UI = QWidget, returned by 'main_widget'.setLayout(layout)
"""


class WidgetPlotFigure(QWidget):

    callbackMessageThrower: Callable[[str], None] = None

    def __init__(self):
        super(WidgetPlotFigure, self).__init__()
        self.ui = Ui_PlotFigure()
        self.ui.setupUi(self)
        self.setLayout(self.ui.gridLayout_main)
        self.bindingSignal2Slot()
        self.list_figures: List[tuple[str, Figure]] = []
        self.boxplot_analyzer = BoxplotAnalyzer()  # Create analyzer instance

    def add_page(self, add_figure: Figure, title: str) -> None:
        canvas = FigureCanvas(add_figure)
        layout = QFormLayout()
        layout.addWidget(canvas)

        new_page = QWidget()
        new_page.setLayout(layout)
        self.ui.tab_plotFigureHolder.addTab(new_page, title)

    def build_figure_pages(self, figureconfig_list: List[FigureConfig], dataset: CSV_Database,
                          userset_label_list: List[str], **kwargs) -> None:
        try:
            if not figureconfig_list:
                raise ValueError("No plot configuration found")

            if not dataset or dataset.data.empty:
                raise ValueError("No data available for plotting")

            # Kiểm tra danh sách nhãn
            if not userset_label_list:
                raise ValueError("No dataset labels provided")

            # Xóa các tab cũ
            self.ui.tab_plotFigureHolder.clear()
            self.list_figures.clear()

            # Tạo các figure mới
            for figure_config in figureconfig_list:
                try:
                    # Đếm số lượng plot có dữ liệu trong figure này
                    valid_plots = 0
                    for plot in figure_config.plotconfig_list:
                        if plot.to_plot:
                            plot_dataset = dataset.from_column(
                                column=plot.item_name,
                                removeNaN=True,
                                sort_data_order_by=userset_label_list)
                            if plot_dataset is not None:
                                # Kiểm tra xem có dữ liệu thực sự không
                                has_data = False
                                for _, (status, data) in plot_dataset.items():
                                    if status == 'has_data' and len(data) > 0:
                                        has_data = True
                                        break
                                if has_data:
                                    valid_plots += 1

                    # Chỉ tạo figure nếu có ít nhất một plot có dữ liệu
                    if valid_plots > 0:
                        # Đảm bảo dataset_label_size được truyền vào từ kwargs
                        if 'dataset_label_size' not in kwargs:
                            kwargs['dataset_label_size'] = Setting.OPTS_DATASET_LABEL_FONT_SIZE
                        
                        fig = self.build_figure(
                            figure_config=figure_config,
                            dataset=dataset,
                            userset_label_list=userset_label_list,
                            **kwargs
                        )
                        if fig is not None:  # Thêm kiểm tra này để đảm bảo figure được tạo thành công
                            self.list_figures.append((figure_config.name, fig))
                            self.add_page(fig, figure_config.title)
                    else:
                        self.callbackMessageThrower(f"Skipped empty figure: {figure_config.title}")

                except Exception as e:
                    raise ValueError(f"Error creating plot '{figure_config.title}': {str(e)}")

        except Exception as e:
            # Chuyển tiếp lỗi để controller xử lý
            raise ValueError(f"Failed to build plots: {str(e)}")

    def build_figure(
            self,
            figure_config: FigureConfig,
            dataset: CSV_Database,
            userset_label_list: List[str],
            label_rotation: int,
            show_median: bool = False,
            show_cpk: bool = False,
            show_n: bool = False,
            show_violin: bool = True,
            show_individual: bool = True,
            use_gradient: bool = False,
            median_size: int = 2,
            show_abnormal: bool = True,
            dataset_label_size: int = 5
    ) -> Figure:
        # Đếm số lượng plot thực sự cần vẽ
        active_plots = sum(1 for plot in figure_config.plotconfig_list if plot.to_plot)
        
        if active_plots == 0:
            return None

        # Tính toán lại kích thước grid dựa trên số plot thực tế
        if active_plots == 1:
            row_size, col_size = 1, 1
        elif active_plots == 2:
            row_size, col_size = 1, 2
        elif active_plots == 3:
            row_size, col_size = 1, 3
        elif active_plots <= 4:
            row_size, col_size = 2, 2
        elif active_plots <= 6:
            row_size, col_size = 2, 3
        elif active_plots <= 9:
            row_size, col_size = 3, 3
        elif active_plots <= 12:
            row_size, col_size = 3, 4
        elif active_plots <= 16:
            row_size, col_size = 4, 4
        else:
            # Nếu có nhiều hơn 16 plots, tính toán kích thước grid tự động
            col_size = min(6, int(np.ceil(np.sqrt(active_plots))))  # Giới hạn tối đa 6 cột
            row_size = int(np.ceil(active_plots / col_size))

        fig = Figure()

        # Tạo subplots và xử lý trường hợp một subplot
        if row_size == 1 and col_size == 1:
            axs = fig.add_subplot(111)
            axs = np.array([[axs]])
        else:
            axs = fig.subplots(row_size, col_size)
            if row_size == 1 or col_size == 1:
                axs = axs.reshape(row_size, col_size)

        plot_idx = 0

        # Reset anomaly tracker for new figure
        self.boxplot_analyzer.has_any_anomaly = False

        # Xóa các subplot không sử dụng
        for idx in range(active_plots, row_size * col_size):
            ax = axs.flat[idx]
            fig.delaxes(ax)

        for plot in figure_config.plotconfig_list:
            if plot.to_plot is False:
                continue

            ax = axs.flat[plot_idx]
            plot_dataset = dataset.from_column(
                column=plot.item_name,
                removeNaN=True,
                sort_data_order_by=userset_label_list)
            if plot_dataset is None:
                continue

            # Xử lý các trường hợp dữ liệu
            data_list = []
            labels = []
            has_data = False
            
            # Tìm giá trị min, max của toàn bộ dữ liệu để thiết lập trục y
            all_data = []
            for name, (status, data) in plot_dataset.items():
                labels.append(name)
                if status == 'has_data':
                    data_list.append(data)
                    all_data.extend(data)  # Thêm tất cả dữ liệu vào một list
                    has_data = True
                else:
                    data_list.append([])

            # Di chuyển phần tạo gradient colors xuống đây
            if use_gradient:
                # Sử dụng bảng màu đa dạng và tương phản
                base_colors = [
                    ('#FF6B6B', '#EE5253'),  # Đỏ tươi
                    ('#4834D4', '#686DE0'),  # Tím xanh
                    ('#26de81', '#20bf6b'),  # Xanh lá
                    ('#F79F1F', '#EE5A24'),  # Cam
                    ('#1B9CFC', '#0652DD'),  # Xanh dương
                    ('#A8E6CF', '#1DD1A1'),  # Xanh mint
                    ('#FDA7DF', '#D980FA'),  # Hồng
                    ('#45aaf2', '#2d98da'),  # Xanh biển
                    ('#F8EFBA', '#FDB827'),  # Vàng
                    ('#BDC581', '#A3CB38'),  # Xanh chuối
                    ('#D6A2E8', '#9B59B6'),  # Tím
                    ('#6D214F', '#82589F'),  # Tím đậm
                    ('#182C61', '#3B3B98'),  # Xanh đen
                    ('#FC427B', '#CD1042'),  # Hồng đậm
                    ('#25CCF7', '#67E6DC')   # Xanh ngọc
                ]

                # Tạo thêm màu bằng cách đảo ngược các cặp màu
                gradient_colors = base_colors.copy()
                if len(data_list) > len(base_colors):
                    # Tạo màu mới bằng cách đảo ngược gradient và điều chỉnh độ sáng
                    for color1, color2 in base_colors:
                        # Chuyển RGB sang HLS
                        h1, l1, s1 = colorsys.rgb_to_hls(*[x/255 for x in bytes.fromhex(color1[1:])])
                        h2, l2, s2 = colorsys.rgb_to_hls(*[x/255 for x in bytes.fromhex(color2[1:])])
                        
                        # Điều chỉnh độ sáng và màu sắc
                        new_h1 = (h1 + 0.5) % 1.0  # Đảo ngược màu sắc
                        new_h2 = (h2 + 0.5) % 1.0
                        new_l1 = min(1.0, l1 * 1.2)  # Tăng độ sáng
                        new_l2 = min(1.0, l2 * 1.2)
                        
                        # Chuyển lại RGB
                        rgb1 = colorsys.hls_to_rgb(new_h1, new_l1, s1)
                        rgb2 = colorsys.hls_to_rgb(new_h2, new_l2, s2)
                        
                        # Chuyển RGB thành hex
                        new_color1 = '#%02x%02x%02x' % tuple(int(x * 255) for x in rgb1)
                        new_color2 = '#%02x%02x%02x' % tuple(int(x * 255) for x in rgb2)
                        
                        gradient_colors.append((new_color1, new_color2))

            # Vẽ boxplot và violin plot nếu có dữ liệu
            if has_data:
                if use_gradient:
                    # TRƯỜNG HỢP 1: Sử dụng màu gradient
                    if show_violin:
                        valid_data = [d for d in data_list if len(d) > 0]
                        valid_positions = [i+1 for i, d in enumerate(data_list) if len(d) > 0]
                        
                        if valid_data:
                            parts = ax.violinplot(valid_data,
                                                positions=valid_positions,
                                                showmeans=False,
                                                showmedians=False,
                                                showextrema=False,
                                                widths=0.7)

                            for idx, pc in enumerate(parts['bodies']):
                                color_idx = idx % len(gradient_colors)
                                main_color = gradient_colors[color_idx][0]
                                pc.set_facecolor(main_color)
                                pc.set_edgecolor('none')
                                pc.set_alpha(0.4)
                                pc.set_linewidth(1)

                    bp = ax.boxplot(data_list,
                                   labels=labels,
                                   patch_artist=True,
                                   medianprops={'color': 'black', 'linewidth': 0.75},
                                   whiskerprops={'color': 'black', 'linewidth': 0.5, 'linestyle': '--'},
                                   capprops={'color': 'black', 'linewidth': 0.5},
                                   flierprops={'marker': 'o', 'markerfacecolor': 'white', 
                                             'markeredgecolor': 'black', 'markersize': 3})

                    # Áp dụng màu gradient cho boxplot
                    for idx, box in enumerate(bp['boxes']):
                        color_idx = idx % len(gradient_colors)
                        main_color, darker_color = gradient_colors[color_idx]
                        box.set_facecolor(main_color)
                        box.set_edgecolor(darker_color)
                        box.set_linewidth(1)
                        
                        whisker_idx = idx * 2
                        bp['whiskers'][whisker_idx].set_color(darker_color)
                        bp['whiskers'][whisker_idx + 1].set_color(darker_color)
                        bp['medians'][idx].set_color(darker_color)
                        if len(bp['fliers']) > idx:
                            bp['fliers'][idx].set_markerfacecolor(main_color)
                            bp['fliers'][idx].set_markeredgecolor(darker_color)

                    # Thêm các đường ngang ở whisker với màu gradient
                    for i, data in enumerate(bp['whiskers'][::2], start=1):
                        lower_whisker = bp['whiskers'][2 * (i - 1)].get_ydata()[1]
                        upper_whisker = bp['whiskers'][2 * (i - 1) + 1].get_ydata()[1]
                        color = gradient_colors[(i-1) % len(gradient_colors)][1]
                        ax.hlines(lower_whisker, i - 0.05, i + 0.05, color=color, linewidth=0.5)
                        ax.hlines(upper_whisker, i - 0.05, i + 0.05, color=color, linewidth=0.5)

                else:
                    # TRƯỜNG HỢP 2: Sử dụng format mặc định từ code ban đầu
                    if show_violin:
                        valid_data = [d for d in data_list if len(d) > 0]
                        valid_positions = [i+1 for i, d in enumerate(data_list) if len(d) > 0]
                        
                        if valid_data:
                            parts = ax.violinplot(valid_data,
                                                positions=valid_positions,
                                                showmeans=False,
                                                showmedians=False,
                                                showextrema=False,
                                                widths=0.7)

                            for pc in parts['bodies']:
                                pc.set_facecolor('#ADD8E6')
                                pc.set_edgecolor('none')
                                pc.set_alpha(0.4)
                                pc.set_linewidth(1)

                    bp = ax.boxplot(data_list,
                                   labels=labels,
                                   patch_artist=True,
                                   medianprops={'color': 'black', 'linewidth': 0.75},
                                   boxprops={'facecolor': "#ECECEC", 'edgecolor': 'black'},
                                   whiskerprops={'color': 'black', 'linewidth': 0.5, 'linestyle': '--'},
                                   capprops={'color': 'black', 'linewidth': 0.5},
                                   flierprops={'marker': 'o', 'markerfacecolor': 'white', 
                                             'markeredgecolor': 'black', 'markersize': 3})

                    # Thêm các đường ngang ở whisker với màu đen
                    for i, data in enumerate(bp['whiskers'][::2], start=1):
                        lower_whisker = bp['whiskers'][2 * (i - 1)].get_ydata()[1]
                        upper_whisker = bp['whiskers'][2 * (i - 1) + 1].get_ydata()[1]
                        ax.hlines(lower_whisker, i - 0.05, i + 0.05, color='black', linewidth=0.5)
                        ax.hlines(upper_whisker, i - 0.05, i + 0.05, color='black', linewidth=0.5)

                # Analyze and highlight anomalies
                if show_abnormal:
                    self.boxplot_analyzer.analyze_and_highlight(
                        ax=ax,
                        bp=bp,
                        data_list=data_list,
                        lsl=plot.lowerspec,
                        usl=plot.upperspec
                    )

                # Xử lý thông tin thống kê chỉ cho các dataset có dữ liệu
                for i, (name, (status, data)) in enumerate(plot_dataset.items()):
                    if status == 'has_data':
                        median = bp['medians'][i].get_ydata()[0]
                        q3 = np.percentile(data, 75)
                        y_pos = q3 + 0.01 * (ax.get_ylim()[1] - ax.get_ylim()[0])
                        x_pos = i + 1.1

                        text = []
                        if show_n:
                            # Đếm số lượng dữ liệu dựa trên tên file
                            n_count = dataset.get_data_by_filename(name)
                            text.append(f"N:{n_count}")
                        if show_median:
                            text.append(f"Med:{median:.4f}")
                        if show_cpk and len(data) > 1:
                            mean = np.mean(data)
                            std_dev = np.std(data)
                            if plot.lowerspec is not None and plot.upperspec is not None:
                                cpk = min((plot.upperspec - mean) / (3 * std_dev), 
                                         (mean - plot.lowerspec) / (3 * std_dev))
                            elif plot.lowerspec is not None:
                                cpk = (mean - plot.lowerspec) / (3 * std_dev)
                            elif plot.upperspec is not None:
                                cpk = (plot.upperspec - mean) / (3 * std_dev)
                            else:
                                cpk = None

                            if cpk is not None:
                                text.append(f"Cpk:{cpk:.4f}")

                        if text:
                            ax.annotate('\n'.join(text),
                                        xy=(x_pos, y_pos),
                                        xytext=(0, 2),
                                        textcoords='offset points',
                                        fontsize=median_size,
                                        ha='left',
                                        va='bottom',
                                        bbox=dict(boxstyle='round,pad=0.2', 
                                                fc='white', 
                                                ec='#B7B7B7', 
                                                alpha=0.5),
                                        zorder=1)

            # Thêm individual value plot nếu được chọn
            if has_data and show_individual:
                for i, data in enumerate(data_list):
                    if len(data) > 0:
                        # Tạo jitter cho điểm dữ liệu
                        x = np.random.normal(i + 1, 0.04, size=len(data))
                        ax.plot(x, data, 'o', 
                               color='black',
                               alpha=0.3,
                               markersize=2,
                               markerfacecolor='none',
                               markeredgewidth=0.5)

            # Thêm text cho các trường hợp không có dữ liệu
            for i, (name, (status, _)) in enumerate(plot_dataset.items()):
                if status == 'no_item':
                    # Vẽ text "there is no this item" theo chiều dọc
                    ax.text(i+1, ax.get_ylim()[0] + (ax.get_ylim()[1] - ax.get_ylim()[0])*0.5,
                           'This Item was not found',
                           ha='center', va='center',
                           color='red', fontsize=6,
                           bbox=dict(boxstyle='round,pad=0.2', fc='white', ec='#B7B7B7', alpha=0.5),
                           rotation=90)
                elif status == 'empty_data':
                    # Vẽ text "empty data" theo chiều dọc
                    ax.text(i+1, ax.get_ylim()[0] + (ax.get_ylim()[1] - ax.get_ylim()[0])*0.5,
                           'Empty Data',
                           ha='center', va='center',
                           color='red', fontsize=6,
                           bbox=dict(boxstyle='round,pad=0.2', fc='white', ec='#B7B7B7', alpha=0.5),
                           rotation=90)
                elif status == 'no_file':
                    # Vẽ text "no file" theo chiều dọc
                    ax.text(i+1, ax.get_ylim()[0] + (ax.get_ylim()[1] - ax.get_ylim()[0])*0.5,
                           'No File',
                           ha='center', va='center',
                           color='red', fontsize=6,
                           bbox=dict(boxstyle='round,pad=0.2', fc='white', ec='#B7B7B7', alpha=0.5),
                           rotation=90)

            # Tùy chỉnh trục và lưới
            ax.set_title(plot.title, fontsize=Setting.OPTS_PLOT_TITLE_FONT_SIZE, fontweight='bold')
            
            # Thiết lập font size cho dataset labels
            ax.tick_params(axis='x', labelsize=dataset_label_size)
            ax.set_xticklabels(labels, rotation=label_rotation)
            
            # Thiết lập các thông số khác cho trục
            ax.tick_params(axis='y', labelsize=6)  # Chỉ set size cho y-axis labels
            ax.yaxis.grid(True, linestyle='--', which='major', color='lightgray', alpha=0.7)
            ax.set_axisbelow(True)

            # Thêm spec limits với màu đỏ và đường đứt nét
            if plot.lowerspec is not None and isinstance(plot.lowerspec, (int, float)):
                ax.axhline(y=plot.lowerspec, linewidth=0.5, color='red', linestyle='--')
                ax.text(ax.get_xlim()[1], plot.lowerspec, f'{plot.lowerspec}', 
                        verticalalignment='center', horizontalalignment='left',
                        color='red', fontsize=6)

            if plot.upperspec is not None and isinstance(plot.upperspec, (int, float)):
                ax.axhline(y=plot.upperspec, linewidth=0.5, color='red', linestyle='--')
                ax.text(ax.get_xlim()[1], plot.upperspec, f'{plot.upperspec}', 
                        verticalalignment='center', horizontalalignment='left',
                        color='red', fontsize=6)

            plot_idx += 1
            try:
                self.callbackMessageThrower(f"Plotted {plot.title}...")
            except:
                pass

        # Add legend to figure if any anomalies were found
        if self.boxplot_analyzer.has_any_anomaly:
            legend_elements = self.boxplot_analyzer.create_legend_elements()
            
            # Điều chỉnh layout trước
            fig.tight_layout(pad=1.0)
            
            # Tính toán vị trí legend để không đè lên plot
            # Đặt legend ở góc phải trên của figure
            fig.legend(handles=legend_elements,
                      loc='upper right',
                      bbox_to_anchor=(0.98, 0.98),
                      fontsize=5,
                      title='Anomalies',
                      title_fontsize=6,
                      framealpha=0.9,
                      edgecolor='lightgray',
                      borderpad=0.2,
                      handletextpad=0.2,
                      handlelength=0.5,
                      columnspacing=0.5,
                      labelspacing=0.2,
                      ncol=1,
                      markerscale=0.5,
                      frameon=True,
                      fancybox=True,
                      shadow=False)

            # Điều chỉnh layout để chừa chỗ cho legend
            fig.tight_layout(rect=[0, 0, 0.95, 1])  # Chừa 5% không gian bên phải cho legend

        # Standardize the figure size to fit MS PPT report
        WidgetPlotFigure.figure_sizefit(
            figure=fig,
            nrows=row_size,
            ncols=col_size,
            width_height_ratio=Setting.PICTURE_WIDTH_HEIGHT_RATIO,
            max_width=Setting.PICTURE_MAX_WIDTH,
            max_height=Setting.PICTURE_MAX_HEIGHT)

        # Điều chỉnh layout
        fig.tight_layout()

        # Add bounding box to figure
        return fig
    def closeEvent(self, a0: QtGui.QCloseEvent | None) -> None:
        # intentionally close all current existing matplotlib.pyplot figures explicitly
        # to save memory and prevent Matplotlib module from warning about unclosed figures
        plt.close('all')
        return super().closeEvent(a0)

    """
    EXTRA FUNCTION
    """

    def exportFigure2Image(self) -> None:
        for figname, fig in self.list_figures:
            figname = Setting.OUTPUT_DIR + "\\" + figname + ".png"
            fig.savefig(fname=figname, pad_inches=0.05)
            # save figure name to list for future use
            Status.LIST_FIGURE_IMAGES.append(figname)

    def exportFigure2PPTX(self) -> None:
        try:
            img2pptx = ImageEmbedPPTX()
            ImageEmbedPPTX.callbackMessageThrower = self.callbackMessageThrower
            img2pptx.clearAllShapes()
            
            # Chuyển đổi tất cả các tên figure thành string
            self.list_figures = [(str(name), fig) for name, fig in self.list_figures]
            
            img2pptx.exportImages2PPTX()
            
            # Hiển thị thông báo thành công
            output_path = os.path.join(Setting.OUTPUT_DIR, ImageEmbedPPTX.PPTX_OUTPUT_NAME + '.pptx')
            self.ui.showExportSuccess(output_path)
            
        except TypeError as te:
            QMessageBox.critical(
                self,
                "Export Error",
                "Error in figure titles: All titles must be text.\nPlease check your figure configurations.",
                QMessageBox.StandardButton.Ok
            )
        except Exception as e:
            QMessageBox.critical(
                self,
                "Export Error",
                f"Failed to export to PowerPoint:\n{str(e)}",
                QMessageBox.StandardButton.Ok
            )

    @staticmethod
    def figure_sizefit(
            figure: Figure,
            nrows: int,
            ncols: int,
            width_height_ratio: float,  # width/height ratio
            max_width: float,
            max_height: float
    ) -> None:
        if max_width <= 0 or max_height <= 0:
            # raise ValueError("max_width and max_height should be greater than 0")
            return

        # get current figure width and height
        figwidth = figure.get_figwidth()
        figheight = figure.get_figheight()

        # STANDARDIZE SUBPLOT/FIGURE WIDTH PER HEIGHT PROPORTION
        # calculate size of single subplot
        subplot_width = figwidth / ncols
        # subplot_height = figheight / nrows

        # adjust figure height to comply with specified Ratio
        subplot_height = subplot_width / width_height_ratio

        # calculate figure width and height from subplot size
        figheight = subplot_height * nrows
        figwidth = subplot_width * ncols

        # scale figure size to max fit with max_width and max_height
        width_scale = max_width / figwidth
        height_scale = max_height / figheight
        scale = min(width_scale, height_scale)

        new_figwidth = figwidth * scale
        new_figheight = figheight * scale

        # resize the figure to new size fit with max_width, max_height
        figure.set_figwidth(new_figwidth)
        figure.set_figheight(new_figheight)

        return None

    def bindingSignal2Slot(self) -> None:
        self.ui.btn_exportPPTX.clicked.connect(
            self.ui.actionExportGraph2PPTX.trigger)
        self.ui.actionExportGraph2PPTX.triggered.connect(
            self.exportFigure2PPTX)

    # @staticmethod
    # def drawFigureBbox(figure: Figure, axes: Axes) -> None:
    #     # Get the bounding boxes of the axes including text decorations
    #     axes_shape = np.atleast_2d(axes).shape
    #     renderer = figure.canvas.get_renderer()
    #     def get_bbox(ax): return ax.get_tightbbox(
    #         renderer).transformed(figure.transFigure.inverted())
    #     bboxes = list(map(get_bbox, axes.flat))

    #     # Get the minimum and maximum extent, get the coordinate half-way between those
    #     ymax = np.array(list(map(lambda b: b.y1, bboxes))
    #                     ).reshape(axes_shape).max(axis=1)
    #     ymin = np.array(list(map(lambda b: b.y0, bboxes))
    #                     ).reshape(axes_shape).min(axis=1)
    #     ys = np.c_[ymax[1:], ymin[:-1]].mean(axis=1)

    #     # Draw a horizontal lines at those coordinates
    #     for y in ys:
    #         line = plt.Line2D(
    #             [0, 1], [y, y],
    #             linestyle='solid',
    #             linewidth=0.1,
    #             transform=figure.transFigure,
    #             color='black')
    #         figure.add_artist(line)

    #     return None

    # @staticmethod
    # def drawAxisBbox(figure: Figure, axis: Axis) -> None:
    #     # Get the bounding boxes of the axes including text decorations
    #     renderer = figure.canvas.get_renderer()
    #     bbox = axis.get_tightbbox(renderer).transformed(
    #         figure.transFigure.inverted())
    #     rec = patches.Rectangle(
    #         xy=(bbox.x0, bbox.y0),
    #         width=bbox.width,
    #         height=bbox.height,
    #         lw=1,
    #         edgecolor="red",
    #         facecolor="none",
    #         fill=False)
    #     axis.add_patch(rec)

    #     return None

    # binding Action to function