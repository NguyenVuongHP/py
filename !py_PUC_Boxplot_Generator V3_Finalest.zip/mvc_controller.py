from __future__ import annotations
import mvc_model
import mvc_view
from controller.setting import Setting
from controller.workstatus import Status
import os
import glob
from PyQt6.QtWidgets import QDialog, QVBoxLayout, QLabel, QGraphicsDropShadowEffect, QApplication, QMessageBox
from PyQt6.QtGui import QIcon, QPixmap, QColor
from PyQt6.QtCore import Qt, QTimer


# Controller in MVC pattern
class Controller():

    def __init__(self, model: mvc_model.Model, view: mvc_view.View):
        self.model = model
        self.view = view
        self.setting = Setting()
        self.bindSignalAndSlot()
        self.selected_data_directory = None  # Add this variable to store the selected directory
        # Show initial message to UI
        self.view.Main.updateUI_messagebox(f"<b>Program initialized at: </b> \
                                  <font color='blue'>{self.setting.ROOTDIR}\
                                  </font>")
        self.setTooltips()

    def export_database(self) -> None:
        self.model.database.export_to_local(Setting.OUTPUT_DIR)

    def build_boxplot(self) -> None:
        self.view.wxPlotFigure_newWidget()
        if self.view.PlotFigure == None:
            return

        self.view.PlotFigure.callbackMessageThrower = self.view.Main.updateUI_messagebox
        self.view.PlotFigure.build_figure_pages(
            figureconfig_list=self.model.figureconfig_list.list,
            plot_dataset=self.model.database,
            userset_label_list=Setting.PLOTCONFIG_DATASET_NAME_LIST,
            userset_label_rotation=Setting.OPTS_PLOTCONFIG_DATASET_LABEL_ROTATION,
            userset_show_median=Setting.OPTS_PLOTCONFIG_SHOW_MEDIAN,
            userset_show_cpk=Setting.OPTS_PLOTCONFIG_SHOW_CPK,
            userset_show_n=Setting.OPTS_PLOTCONFIG_SHOW_N,
            userset_show_violin=Setting.OPTS_PLOTCONFIG_SHOW_VIOLIN,
            userset_show_individual=Setting.OPTS_PLOTCONFIG_SHOW_INDIVIDUAL,
            userset_median_size=Setting.OPTS_MEDIAN_FONT_SIZE)

        self.view.PlotFigure.exportFigure2Image()
        self.view.PlotFigure.showMaximized()

    """ Grab matched files in Input folder and pass to Model object to import to database """

    def import_input_data(self) -> None:
        # update Setting from user
        self.view.Main.updateUI_messagebox("- User setting loaded")
        input_status_files_count = len(Status.DATA_INPUT_FILE_LIST)

        if input_status_files_count > 0:
            self.view.Main.updateUI_messagebox(
                f"- Found {input_status_files_count} data files to be input")
            Status.INPUT_READY = True
        else:
            Status.INPUT_READY = False
            self.view.Main.updateUI_messagebox(
                "There are no data files in Input directory")
            return None

        # Import data from input folder to Database of Model
        self.model.database.import_csv_files(
            filepaths=Status.DATA_INPUT_FILE_LIST,
            reading_cols=self.model.figureconfig_list.DATA_IMPORT_COLUMN_LIST,
            skip_rows=Setting.OPTS_DATACONFIG_IMPORT_SKIP_ROW,
            callbackMessage=self.view.Main.updateUI_statusbar)

        rows, columns = self.model.database.size
        self.view.Main.updateUI_messagebox(
            f"- Input data imported successfully: {rows} rows - {columns} columns")

    # Define methods execute when occuring Event from View
    def actionMakePlot_procedure(self):
        if not self.selected_data_directory:
            self.view.Main.updateUI_messagebox(
                "Please select a data directory before creating a plot.")
            return

        # Notice to UI
        self.view.Main.updateUI_messagebox(
            f"\n <b>Creating plot from data files in the selected directory</b>...")
        self.model.figureconfig_list.update()
        Status.update()
        Status.LIST_FIGURE_IMAGES.clear()
        Setting.PLOTCONFIG_DATASET_NAME_LIST = self.view.Main.getfromUI_datasetNameList_txtEdit()

        # Update the path in Status
        Status.DATA_INPUT_FILE_LIST = [file for file in glob.glob(
            os.path.join(self.selected_data_directory, f'*.{Setting.FILE_EXT}'))]

        self.import_input_data()
        if not Status.INPUT_READY:
            self.view.Main.updateUI_messagebox(
                "No data files in the selected directory")  # status bar
            return None

        self.export_database()

        # Check if any items from Plot Config exist in the input data
        items_found = False
        for plot_item in self.model.figureconfig_list.DATA_IMPORT_COLUMN_LIST:
            if plot_item in self.model.database.data.columns:
                items_found = True
                break

        if not items_found:
            QMessageBox.critical(
                self.view.Main,
                "No Items Found",
                "None of the items specified in Plot Config.csv were found in the input CSV files.\n\n" +
                "Please check:\n" +
                "1. The item names in Plot Config.csv match the column headers in your input files\n" +
                "2. The input CSV files contain the required data columns\n" +
                "3. The CSV files are properly formatted",
                QMessageBox.StandardButton.Ok
            )
            return

        try:
            loading_dialog = CuteLoadingDialog()
            loading_dialog.show()
            QApplication.processEvents()

            try:
                # Tạo plot window và vẽ box plot
                self.view.wxPlotFigure_newWidget()
                if self.view.PlotFigure == None:
                    loading_dialog.close()
                    return

                self.view.PlotFigure.callbackMessageThrower = self.view.Main.updateUI_messagebox
                
                # Vẽ box plot
                self.view.PlotFigure.build_figure_pages(
                    figureconfig_list=self.model.figureconfig_list.list,
                    dataset=self.model.database,
                    userset_label_list=Setting.PLOTCONFIG_DATASET_NAME_LIST,
                    label_rotation=Setting.OPTS_PLOTCONFIG_DATASET_LABEL_ROTATION,
                    show_median=Setting.OPTS_PLOTCONFIG_SHOW_MEDIAN,
                    show_cpk=Setting.OPTS_PLOTCONFIG_SHOW_CPK,
                    show_n=Setting.OPTS_PLOTCONFIG_SHOW_N,
                    show_violin=Setting.OPTS_PLOTCONFIG_SHOW_VIOLIN,
                    show_individual=Setting.OPTS_PLOTCONFIG_SHOW_INDIVIDUAL,
                    use_gradient=Setting.OPTS_PLOTCONFIG_USE_GRADIENT,
                    median_size=Setting.OPTS_MEDIAN_FONT_SIZE,
                    show_abnormal=Setting.OPTS_PLOTCONFIG_SHOW_ABNORMAL,
                    dataset_label_size=Setting.OPTS_DATASET_LABEL_FONT_SIZE)

                # Export và hiển thị plot
                self.view.PlotFigure.exportFigure2Image()
                self.view.PlotFigure.showMaximized()
                
            except ValueError as e:
                # Hiển thị thông báo lỗi thân thiện với người dùng
                error_msg = str(e)
                if "index" in error_msg and "out of bounds" in error_msg:
                    error_msg = "The number of charts is too large for one figure. Please split the data into multiple figures."
                
                QMessageBox.critical(self.view.Main, 
                                   "Error creating chart",
                                   f"Unable to create chart:\n{error_msg}",
                                   QMessageBox.StandardButton.Ok)
                
            except Exception as e:
                QMessageBox.critical(self.view.Main,
                                   "Unknown error",
                                   f"An unexpected error occurred:\n{str(e)}",
                                   QMessageBox.StandardButton.Ok)
                
        finally:
            loading_dialog.close()

    def actionLoadDatasetName_procedure(self) -> None:
        # Lấy dữ liệu từ thư mục input thay vì hiện cửa sổ lên để chọn
        input_dir = Setting.INPUT_DIR
        self.selected_data_directory = input_dir  # Lưu thư mục đã chọn
        # Cập nhật đường dẫn trong Status
        Status.DATA_INPUT_FILE_LIST = [file for file in glob.glob(
            os.path.join(input_dir, f'*.{Setting.FILE_EXT}'))]
        
        Status.DETECTED_DATASET_NAME_LIST = [os.path.splitext(
            os.path.basename(file))[0] for file in Status.DATA_INPUT_FILE_LIST]
        
        # Cập nhật UI với danh sách tên dataset mới
        self.view.Main.updateUI_datasetNameList_txtEdit(
            Status.DETECTED_DATASET_NAME_LIST)
        
        # Thông báo cho người dùng
        self.view.Main.updateUI_messagebox(
            f"Dataset name list loaded from directory: {input_dir}")
        
        # Kích hoạt nút Make Plot
        self.view.Main.ui.btn_makePlot.setEnabled(True)

    def actionShowPreference_procedure(self) -> None:
        self.view.Preference.setUI_preference(
            Setting.OPTS_PLOTCONFIG_DATASET_LABEL_ROTATION,
            Setting.OPTS_PLOTCONFIG_SHOW_MEDIAN,
            Setting.OPTS_PLOTCONFIG_SHOW_CPK,
            Setting.OPTS_PLOTCONFIG_SHOW_N,
            Setting.OPTS_PLOTCONFIG_SHOW_VIOLIN,
            Setting.OPTS_PLOTCONFIG_SHOW_INDIVIDUAL,
            Setting.OPTS_PLOTCONFIG_USE_GRADIENT,
            Setting.OPTS_MEDIAN_FONT_SIZE,
            Setting.OPTS_PLOT_TITLE_FONT_SIZE,
            Setting.OPTS_DATACONFIG_IMPORT_SKIP_ROW,
            Setting.OPTS_DATASET_LABEL_FONT_SIZE,
            Setting.OPTS_PLOTCONFIG_ONLY_SHOW_ABNORMAL
        )
        self.view.Preference.show()

    # Save user preference
    def actionSavePreference_procedure(self):
        try:
            # Cập nhật số lượng biến để nhận
            [rotation, showMedian, showCpk, showN, showViolin, 
             showIndividual, useGradient, medianSize, titleSize, 
             rowskip, showAbnormal, datasetLabelSize, onlyShowAbnormal] = self.view.Preference.getUI_preference()

            self.setting.saveSetting(
                plotconfig_datasetLabelRotation=rotation,
                plotconfig_showMedian=showMedian,
                plotconfig_showCpk=showCpk,
                plotconfig_showN=showN,
                plotconfig_showViolin=showViolin,
                plotconfig_showIndividual=showIndividual,
                plotconfig_useGradient=useGradient,
                plotconfig_medianFontSize=medianSize,
                plotconfig_titleFontSize=titleSize,
                plotconfig_showAbnormal=showAbnormal,
                plotconfig_datasetLabelFontSize=datasetLabelSize,
                plotconfig_onlyShowAbnormal=onlyShowAbnormal,
                dataconfig_importSkipRows=rowskip
            )

            # Chỉ hiển thị thông báo trên status bar và không emit signal
            self.view.Main.updateUI_statusbar("Preferences saved")
            self.view.Preference.close()  # Đóng cửa sổ preference sau khi lưu

        except Exception as e:
            self.view.Main.updateUI_messagebox(f"Failed to save preferences: {str(e)}")

    """
    Binding PyQt signal & slot
    """

    def bindSignalAndSlot(self):
        self.view.Main.ui.actionMakePlot.triggered.connect(
            self.actionMakePlot_procedure)
        self.view.Main.ui.actionLoadDatasetName.triggered.connect(
            self.actionLoadDatasetName_procedure)
        self.view.Main.ui.actionShowPreference.triggered.connect(
            self.actionShowPreference_procedure)
        self.view.Preference.savePreference.connect(
            self.actionSavePreference_procedure)
        # Xóa kết nối của nút Split Data
        # self.view.Main.ui.actionSplitData.triggered.connect(
        #     self.actionSplitData_procedure)

    def setTooltips(self):
        # Giữ nguyên chú thích cho nút Load Dataset
        self.view.Main.ui.btn_loadDatasetName.setToolTip("Load Dataset name (name of data file).\nThis will be used as data labels for Visual Plot of the data.")
        
        # Thêm chú thích cho các nút khác
        # Xóa chú thích cho nút Split Data
        # self.view.Main.ui.btn_splitData.setToolTip("Select the file to split. \nEnter the exact header of the column to split the data")
        self.view.Main.ui.btn_makePlot.setToolTip("Create boxplot from loaded dataset")
        self.view.Main.ui.btn_showPreference.setToolTip("Show preferences window. \nDisplay options to show Cpk, N, Median value. \nDisplay Violin Plot, Individual Value Plot, Change Colour. \nAdjust font size, angle of label.")
        self.view.Main.ui.btn_showAbout.setToolTip("Show information about the application")
        
        # Thêm lại tooltip cho nút Split Data
        self.view.Main.ui.btn_splitData.setToolTip(
            "Split CSV file by column.\nSelect a file and specify the column to split by."
        )


class CuteLoadingDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Waiting")
        self.setFixedSize(200, 150)
        self.setWindowFlags(
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.FramelessWindowHint
        )
        self.setStyleSheet("""
            QDialog {
                background-color: white;
                border: 2px solid #3498db;
                border-radius: 10px;
            }
            QLabel {
                color: #2c3e50;
                font-size: 14px;
                font-weight: bold;
                font-family: 'Segoe UI';
                background: transparent;
            }
        """)

        layout = QVBoxLayout()
        layout.setSpacing(10)

        # Thêm icon thay vì GIF
        self.icon_label = QLabel()
        self.icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.icon_label.setPixmap(QIcon(":/icons/waiting.png").pixmap(70, 70))

        # Label cho thông điệp
        self.message_label = QLabel("Please Wait ...\nChờ xíu nhé!")
        self.message_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        # Thêm các widget vào layout
        layout.addWidget(self.icon_label)
        layout.addWidget(self.message_label)

        self.setLayout(layout)

        # Timer cho dấu chấm
        self.dot_count = 0
        self.dot_timer = QTimer(self)
        self.dot_timer.timeout.connect(self.update_dots)
        self.dot_timer.setInterval(500)

    def showEvent(self, event):
        super().showEvent(event)
        self.dot_count = 0
        self.dot_timer.start()

    def closeEvent(self, event):
        self.dot_timer.stop()
        super().closeEvent(event)

    def update_dots(self):
        dots = ["", ".", "..", "..."]
        self.message_label.setText(f"Waiting...{dots[self.dot_count]}")
        self.dot_count = (self.dot_count + 1) % len(dots)