from typing import List, Dict, Tuple
import numpy as np
from matplotlib.axes import Axes
import matplotlib.patches as mpatches

class BoxplotAnalyzer:
    """
    A utility class for analyzing and highlighting anomalies in boxplots
    """
    
    def __init__(self):
        self.PINK_COLOR = "#FFB6C1"    # For CPK issues
        self.YELLOW_COLOR = "#FFE5B4"   # For median issues
        self.RED_COLOR = "#FF0000"      # For both issues
        self.NORMAL_COLOR = "#ECECEC"   # For normal boxplots
        self.has_any_anomaly = False    # Track if any plot has anomalies
        self.abnormal_plots = set()  # Thêm set để lưu các plot bất thường
        
    def analyze_and_highlight(self, 
                            ax: Axes,
                            bp: dict,
                            data_list: List[np.ndarray],
                            plot_index: int = 0,  # Thêm tham số index
                            lsl: float = None,
                            usl: float = None) -> bool:
        """
        Analyze boxplots and highlight anomalies
        Returns: True if any anomalies were found
        """
        # Calculate medians for all valid data
        valid_medians = []
        cpks = []
        has_anomaly = False
        all_data = []  # Để tính overall median và IQR
        
        # First pass: collect all valid medians and data
        for data in data_list:
            if len(data) > 0:
                median = np.median(data)
                valid_medians.append(median)
                all_data.extend(data)  # Gộp tất cả dữ liệu để tính overall stats
                
                # Calculate CPK if specs exist
                if lsl is not None and usl is not None:
                    mean = np.mean(data)
                    std = np.std(data)
                    if std > 0:
                        cpk = min((usl - mean)/(3*std), (mean - lsl)/(3*std))
                        cpks.append(cpk)
                    else:
                        cpks.append(None)
                else:
                    cpks.append(None)
            else:
                valid_medians.append(None)
                cpks.append(None)

        # Tính overall median và IQR từ tất cả dữ liệu
        if len(all_data) > 0:
            overall_median = np.median(all_data)
            q1 = np.percentile(all_data, 25)
            q3 = np.percentile(all_data, 75)
            iqr = q3 - q1
            lower_bound = q1 - 1.5 * iqr
            upper_bound = q3 + 1.5 * iqr

            # Second pass: analyze each boxplot
            for i, (median, cpk) in enumerate(zip(valid_medians, cpks)):
                if median is None:
                    continue
                    
                color = self.NORMAL_COLOR
                
                # Check for CPK anomaly
                has_cpk_issue = False
                if cpk is not None and cpk < 1.33:
                    has_cpk_issue = True
                    has_anomaly = True
                
                # Check for median anomaly using new criteria
                has_median_issue = False
                
                # Điều kiện 1: |Median nhóm - Overall Median| > 50% Overall Median
                median_deviation = abs(median - overall_median)
                if median_deviation > 0.5 * abs(overall_median):
                    has_median_issue = True
                    has_anomaly = True
                
                # Điều kiện 2: Median nằm ngoài ngưỡng IQR
                if median < lower_bound or median > upper_bound:
                    has_median_issue = True
                    has_anomaly = True
                
                # Set colors based on issues
                if has_cpk_issue and has_median_issue:
                    color = self.RED_COLOR
                    self.abnormal_plots.add(plot_index)  # Thêm vào set bất thường
                elif has_cpk_issue:
                    color = self.PINK_COLOR
                    self.abnormal_plots.add(plot_index)  # Thêm vào set bất thường
                elif has_median_issue:
                    color = self.YELLOW_COLOR
                    self.abnormal_plots.add(plot_index)  # Thêm vào set bất thường
                
                # Apply highlighting
                box = bp['boxes'][i]
                box.set_facecolor(color)
                box.set_alpha(0.7)

            if has_anomaly:
                self.has_any_anomaly = True
            
        return has_anomaly

    def is_plot_abnormal(self, plot_index: int) -> bool:
        """Kiểm tra xem plot có bất thường không"""
        return plot_index in self.abnormal_plots

    def reset(self):
        """Reset trạng thái của analyzer"""
        self.has_any_anomaly = False
        self.abnormal_plots.clear()

    def create_legend_elements(self):
        """Create very compact legend elements for anomalies"""
        return [
            mpatches.Patch(facecolor=self.PINK_COLOR, alpha=0.7, 
                         label='Cpk<1.33'),      # Rút gọn hơn nữa
            mpatches.Patch(facecolor=self.YELLOW_COLOR, alpha=0.7, 
                         label='Med>2σ'),        # Đã ngắn gọn
            mpatches.Patch(facecolor=self.RED_COLOR, alpha=0.7, 
                         label='Both')           # Đã ngắn gọn
        ]

    def add_legend(self, ax: Axes):
        """Add a legend to the plot"""
        if self.has_any_anomaly:
            # Create legend elements
            legend_elements = self.create_legend_elements()

            # Add legend in the best location that doesn't overlap with the plot
            ax.legend(handles=legend_elements, 
                     loc='center left',    # You can adjust this location
                     bbox_to_anchor=(1.02, 0.5),  # Place legend outside the plot
                     fontsize=8,
                     title='Anomalies',
                     title_fontsize=9,
                     framealpha=0.8,
                     edgecolor='gray')

            # Adjust layout to make room for legend
            ax.figure.tight_layout()

    def analyze_only(self, 
                    data_list: List[np.ndarray],
                    plot_index: int = 0,
                    lsl: float = None,
                    usl: float = None) -> bool:
        """
        Chỉ phân tích để đánh dấu plot bất thường, không tô màu
        """
        # Calculate medians for all valid data
        valid_medians = []
        cpks = []
        has_anomaly = False
        all_data = []
        
        # First pass: collect all valid medians and data
        for data in data_list:
            if len(data) > 0:
                median = np.median(data)
                valid_medians.append(median)
                all_data.extend(data)
                
                # Calculate CPK if specs exist
                if lsl is not None and usl is not None:
                    mean = np.mean(data)
                    std = np.std(data)
                    if std > 0:
                        cpk = min((usl - mean)/(3*std), (mean - lsl)/(3*std))
                        cpks.append(cpk)
                    else:
                        cpks.append(None)
                else:
                    cpks.append(None)
            else:
                valid_medians.append(None)
                cpks.append(None)

        # Tính overall median và IQR từ tất cả dữ liệu
        if len(all_data) > 0:
            overall_median = np.median(all_data)
            q1 = np.percentile(all_data, 25)
            q3 = np.percentile(all_data, 75)
            iqr = q3 - q1
            lower_bound = q1 - 1.5 * iqr
            upper_bound = q3 + 1.5 * iqr

            # Second pass: analyze each boxplot
            for i, (median, cpk) in enumerate(zip(valid_medians, cpks)):
                if median is None:
                    continue
                    
                has_cpk_issue = False
                has_median_issue = False
                
                # Check for CPK anomaly
                if cpk is not None and cpk < 1.33:
                    has_cpk_issue = True
                    has_anomaly = True
                
                # Check for median anomalies
                median_deviation = abs(median - overall_median)
                if median_deviation > 0.5 * abs(overall_median):
                    has_median_issue = True
                    has_anomaly = True
                
                if median < lower_bound or median > upper_bound:
                    has_median_issue = True
                    has_anomaly = True
                
                # Đánh dấu plot bất thường nếu có vấn đề
                if has_cpk_issue or has_median_issue:
                    self.abnormal_plots.add(plot_index)
                    self.has_any_anomaly = True
        
        return has_anomaly 