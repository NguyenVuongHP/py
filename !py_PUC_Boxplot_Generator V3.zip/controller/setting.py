from __future__ import annotations
import os
import configparser
from typing import List


class Setting:

    ROOTDIR = os.path.abspath('')
    FILE_EXT: str = 'csv'
    LOCAL_FIGURECONFIG_FILENAME: str = 'Plot Config.csv'

    INPUT_DIR = os.path.abspath("Input")
    OUTPUT_DIR = os.path.abspath("Output")

    # Local preference which load from local and show on UI
    OPTS_LOCAL_FILENAME = 'preference.ini'
    # Rotation of Dataset label on Plot Figure. # 0: no rotation
    OPTS_PLOTCONFIG_DATASET_LABEL_ROTATION: int = 0
    OPTS_PLOTCONFIG_SHOW_MEDIAN: bool = False
    OPTS_MEDIAN_FONT_SIZE: int = 6
    OPTS_DATACONFIG_IMPORT_SKIP_ROW = [1, 2]  # List of integer

    # following Minitab software Boxplot style
    PICTURE_WIDTH_HEIGHT_RATIO: float = 1.48
    PICTURE_MAX_WIDTH: float = 10.5
    PICTURE_MAX_HEIGHT: float = 4.65
    PLOTCONFIG_DATASET_NAME_LIST: List[str] = []

    # Added as per instructions
    OPTS_PLOTCONFIG_SHOW_CPK: bool = False  # Thêm dòng này
    OPTS_PLOTCONFIG_SHOW_N: bool = False    # Thêm dòng này
    OPTS_PLOTCONFIG_SHOW_VIOLIN = True  # Giá trị mặc định
    OPTS_PLOTCONFIG_SHOW_INDIVIDUAL = True  # Thêm setting mới cho individual plot
    OPTS_PLOTCONFIG_USE_GRADIENT = True  # Mặc định bật gradient colors

    # Thêm setting mới cho Plot Title font size
    OPTS_PLOT_TITLE_FONT_SIZE: int = 6  # Giá trị mặc định là 6

    # Thêm biến setting mới
    OPTS_PLOTCONFIG_SHOW_ABNORMAL: bool = True  # Default là True

    def __init__(self):
        self.cfgparser = configparser.ConfigParser()
        self.cfgparser.optionxform = str  # preserve case when read/write from/to INI file
        
        # Kiểm tra xem section 'OPTION' đã tồn tại chưa
        if not self.cfgparser.has_section('OPTION'):
            self.cfgparser.add_section('OPTION')
        
        # Thêm giá trị mặc định cho PLOT_SHOW_ABNORMAL
        if 'PLOT_SHOW_ABNORMAL' not in self.cfgparser['OPTION']:
            self.cfgparser['OPTION']['PLOT_SHOW_ABNORMAL'] = str(Setting.OPTS_PLOTCONFIG_SHOW_ABNORMAL)
        
        # Load settings từ file
        self.loadSetting()

    def loadSetting(self) -> None:
        # Đọc file preference.ini nếu tồn tại
        if os.path.exists("preference.ini"):
            self.cfgparser.read("preference.ini")
        
        # Initialization
        dataset_labelrotation = 0
        rowskip = ""
        show_median = False
        show_cpk = False
        show_n = False
        show_violin = True
        median_fontsize = 6
        show_individual = True
        use_gradient = True  # Giá trị mặc định cho gradient

        # PARSING VALUE FROM LOCAL FILE
        try:
            dataset_labelrotation = self.cfgparser["OPTION"]["DATASET_LABEL_ROTATION"]
        except:
            pass
        try:
            rowskip = self.cfgparser["OPTION"]["DATA_IMPORT_SKIP_ROW_NUMBER"]
        except:
            pass
        try:
            show_median = self.cfgparser["OPTION"]["PLOT_SHOW_MEDIAN"]
        except:
            pass
        try:
            show_cpk = self.cfgparser["OPTION"]["PLOT_SHOW_CPK"]
        except:
            pass
        try:
            show_n = self.cfgparser["OPTION"]["PLOT_SHOW_N"]
        except:
            pass
        try:
            show_violin = self.cfgparser["OPTION"]["PLOT_SHOW_VIOLIN"]
        except:
            pass
        try:
            median_fontsize = self.cfgparser["OPTION"]["MEDIAN_FONT_SIZE"]
        except:
            pass
        try:
            show_individual = self.cfgparser["OPTION"]["PLOT_SHOW_INDIVIDUAL"]
        except:
            pass
        try:
            use_gradient = self.cfgparser["OPTION"]["PLOT_USE_GRADIENT"]
        except:
            pass

        # Handle data type
        try:
            dataset_labelrotation = int(dataset_labelrotation)
        except:
            dataset_labelrotation = 0

        # Xử lý các giá trị boolean
        if show_median == 'True':
            show_median = True
        else:
            show_median = False

        if show_cpk == 'True':
            show_cpk = True
        else:
            show_cpk = False

        if show_n == 'True':
            show_n = True
        else:
            show_n = False

        if show_violin == 'True':
            show_violin = True
        else:
            show_violin = False

        if show_individual == 'True':
            show_individual = True
        else:
            show_individual = False

        if use_gradient == 'True':
            use_gradient = True
        else:
            use_gradient = False

        if not median_fontsize == None:
            median_fontsize = 6  # default value
        elif median_fontsize.isnumeric():
            median_fontsize = int(median_fontsize)
            if not median_fontsize in (3, 10):
                median_fontsize = 6  # default value
        else:
            median_fontsize = 6

        if type(rowskip) == str:
            rowskip = rowskip.split(' ')
            rowskip = [num for num in rowskip if num.isnumeric()]
            rowskip = list(map(int, rowskip))
            rowskip = [row for row in rowskip if row >= 0]
            if len(rowskip) == 0:
                rowskip = None
        else:
            rowskip = None

        # Thêm vào phần load setting
        plot_title_fontsize = 6
        try:
            plot_title_fontsize = self.cfgparser["OPTION"]["PLOT_TITLE_FONT_SIZE"]
        except:
            pass

        try:
            plot_title_fontsize = int(plot_title_fontsize)
            if not plot_title_fontsize in range(2, 11):  # Thay đổi range thành 2-10
                plot_title_fontsize = 6
        except:
            plot_title_fontsize = 6

        # Thêm vào hàm load
        try:
            Setting.OPTS_PLOTCONFIG_SHOW_ABNORMAL = self.cfgparser["OPTION"].getboolean(
                "PLOT_SHOW_ABNORMAL", Setting.OPTS_PLOTCONFIG_SHOW_ABNORMAL)
        except:
            pass

        # save to Setting object
        Setting.OPTS_PLOTCONFIG_DATASET_LABEL_ROTATION = dataset_labelrotation
        Setting.OPTS_PLOTCONFIG_SHOW_MEDIAN = show_median
        Setting.OPTS_PLOTCONFIG_SHOW_CPK = show_cpk
        Setting.OPTS_PLOTCONFIG_SHOW_N = show_n
        Setting.OPTS_PLOTCONFIG_SHOW_VIOLIN = show_violin
        Setting.OPTS_MEDIAN_FONT_SIZE = median_fontsize
        Setting.OPTS_DATACONFIG_IMPORT_SKIP_ROW = rowskip
        Setting.OPTS_PLOTCONFIG_SHOW_INDIVIDUAL = show_individual
        Setting.OPTS_PLOTCONFIG_USE_GRADIENT = use_gradient
        Setting.OPTS_PLOT_TITLE_FONT_SIZE = plot_title_fontsize

    def saveSetting(
            self,
            plotconfig_datasetLabelRotation: int,
            plotconfig_showMedian: bool,
            plotconfig_showCpk: bool,
            plotconfig_showN: bool,
            plotconfig_showViolin: bool,
            plotconfig_showIndividual: bool,
            plotconfig_useGradient: bool,
            plotconfig_medianFontSize: int,
            plotconfig_titleFontSize: int,  # Thêm tham số mới
            plotconfig_showAbnormal: bool,  # Thêm tham số mới
            dataconfig_importSkipRows: List[int]
    ) -> None:
        # argument validation
        if type(plotconfig_datasetLabelRotation) != int:
            plotconfig_datasetLabelRotation = 0
        if not plotconfig_datasetLabelRotation in [0, 45, 90]:
            plotconfig_datasetLabelRotation = 0

        if type(plotconfig_showMedian) != bool:
            plotconfig_showMedian = False
        
        if type(plotconfig_showCpk) != bool:
            plotconfig_showCpk = False
        
        if type(plotconfig_showN) != bool:
            plotconfig_showN = False
        
        if type(plotconfig_showViolin) != bool:
            plotconfig_showViolin = True

        if type(plotconfig_showIndividual) != bool:
            plotconfig_showIndividual = True

        if type(plotconfig_useGradient) != bool:
            plotconfig_useGradient = True

        if type(plotconfig_medianFontSize) != int:
            plotconfig_medianFontSize = 6

        if type(dataconfig_importSkipRows) != list:
            dataconfig_importSkipRows = None
        else:
            dataconfig_importSkipRows = [
                num for num in dataconfig_importSkipRows if type(num) == int]

        # Thêm validation cho title font size
        if type(plotconfig_titleFontSize) != int:
            plotconfig_titleFontSize = 6
        elif plotconfig_titleFontSize not in range(2, 11):
            plotconfig_titleFontSize = 6

        Setting.OPTS_PLOTCONFIG_DATASET_LABEL_ROTATION = plotconfig_datasetLabelRotation
        Setting.OPTS_PLOTCONFIG_SHOW_MEDIAN = plotconfig_showMedian
        Setting.OPTS_PLOTCONFIG_SHOW_CPK = plotconfig_showCpk
        Setting.OPTS_PLOTCONFIG_SHOW_N = plotconfig_showN
        Setting.OPTS_PLOTCONFIG_SHOW_VIOLIN = plotconfig_showViolin
        Setting.OPTS_PLOTCONFIG_SHOW_INDIVIDUAL = plotconfig_showIndividual
        Setting.OPTS_MEDIAN_FONT_SIZE = plotconfig_medianFontSize
        Setting.OPTS_DATACONFIG_IMPORT_SKIP_ROW = dataconfig_importSkipRows
        Setting.OPTS_PLOTCONFIG_USE_GRADIENT = plotconfig_useGradient
        Setting.OPTS_PLOT_TITLE_FONT_SIZE = plotconfig_titleFontSize
        Setting.OPTS_PLOTCONFIG_SHOW_ABNORMAL = plotconfig_showAbnormal

        self.cfgparser["OPTION"]["DATASET_LABEL_ROTATION"] = str(plotconfig_datasetLabelRotation)
        self.cfgparser["OPTION"]["PLOT_SHOW_MEDIAN"] = str(plotconfig_showMedian)
        self.cfgparser["OPTION"]["PLOT_SHOW_CPK"] = str(plotconfig_showCpk)
        self.cfgparser["OPTION"]["PLOT_SHOW_N"] = str(plotconfig_showN)
        self.cfgparser["OPTION"]["PLOT_SHOW_VIOLIN"] = str(plotconfig_showViolin)
        self.cfgparser["OPTION"]["PLOT_SHOW_INDIVIDUAL"] = str(plotconfig_showIndividual)
        self.cfgparser["OPTION"]["MEDIAN_FONT_SIZE"] = str(plotconfig_medianFontSize)
        self.cfgparser["OPTION"]["PLOT_USE_GRADIENT"] = str(plotconfig_useGradient)
        self.cfgparser["OPTION"]["PLOT_TITLE_FONT_SIZE"] = str(plotconfig_titleFontSize)
        self.cfgparser["OPTION"]["PLOT_SHOW_ABNORMAL"] = str(plotconfig_showAbnormal)

        if dataconfig_importSkipRows == None:
            self.cfgparser["OPTION"]["DATA_IMPORT_SKIP_ROW_NUMBER"] = str('None')
        else:
            self.cfgparser["OPTION"]["DATA_IMPORT_SKIP_ROW_NUMBER"] = ' '.join(
                map(str, dataconfig_importSkipRows))

        with open("preference.ini", "w") as configfile:
            self.cfgparser.write(configfile)
            configfile.close()
