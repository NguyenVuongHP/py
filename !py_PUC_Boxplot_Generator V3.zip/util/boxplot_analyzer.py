from typing import List, Dict, Tuple
import numpy as np
from matplotlib.axes import Axes
import matplotlib.patches as mpatches

class BoxplotAnalyzer:
    """
    A utility class for analyzing and highlighting anomalies in boxplots
    """
    
    def __init__(self):
        self.PINK_COLOR = "#FFB6C1"    # For CPK issues
        self.YELLOW_COLOR = "#FFE5B4"   # For median issues
        self.RED_COLOR = "#FF0000"      # For both issues
        self.NORMAL_COLOR = "#ECECEC"   # For normal boxplots
        self.has_any_anomaly = False    # Track if any plot has anomalies
        
    def analyze_and_highlight(self, 
                            ax: Axes,
                            bp: dict,
                            data_list: List[np.ndarray],
                            lsl: float = None,
                            usl: float = None) -> bool:
        """
        Analyze boxplots and highlight anomalies
        Returns: True if any anomalies were found
        """
        # Calculate medians for all valid data
        valid_medians = []
        cpks = []
        has_anomaly = False
        
        # First pass: collect all valid medians
        for data in data_list:
            if len(data) > 0:
                median = np.median(data)
                valid_medians.append(median)
                
                # Calculate CPK if specs exist
                if lsl is not None and usl is not None:
                    mean = np.mean(data)
                    std = np.std(data)
                    if std > 0:
                        cpk = min((usl - mean)/(3*std), (mean - lsl)/(3*std))
                        cpks.append(cpk)
                    else:
                        cpks.append(None)
                else:
                    cpks.append(None)
            else:
                valid_medians.append(None)
                cpks.append(None)

        # Calculate median statistics
        if len([m for m in valid_medians if m is not None]) > 1:  # Need at least 2 valid medians
            median_mean = np.mean([m for m in valid_medians if m is not None])
            median_std = np.std([m for m in valid_medians if m is not None])
            
            # Second pass: analyze each boxplot
            for i, (median, cpk) in enumerate(zip(valid_medians, cpks)):
                if median is None:
                    continue
                    
                color = self.NORMAL_COLOR
                
                # Check for CPK anomaly
                has_cpk_issue = False
                if cpk is not None and cpk < 1.33:
                    has_cpk_issue = True
                    has_anomaly = True
                
                # Check for median anomaly using Z-score
                has_median_issue = False
                if median_std > 0:  # Avoid division by zero
                    z_score = (median - median_mean) / median_std  # Correct Z-score formula
                    if abs(z_score) > 2:  # More than 2 standard deviations
                        has_median_issue = True
                        has_anomaly = True
                
                # Set colors based on issues
                if has_cpk_issue and has_median_issue:
                    color = self.RED_COLOR
                elif has_cpk_issue:
                    color = self.PINK_COLOR
                elif has_median_issue:
                    color = self.YELLOW_COLOR
                
                # Apply highlighting
                box = bp['boxes'][i]
                box.set_facecolor(color)
                box.set_alpha(0.7)

        if has_anomaly:
            self.has_any_anomaly = True
        return has_anomaly

    def create_legend_elements(self):
        """Create very compact legend elements for anomalies"""
        return [
            mpatches.Patch(facecolor=self.PINK_COLOR, alpha=0.7, 
                         label='Cpk<1.33'),      # Rút gọn hơn nữa
            mpatches.Patch(facecolor=self.YELLOW_COLOR, alpha=0.7, 
                         label='Med>2σ'),        # Đã ngắn gọn
            mpatches.Patch(facecolor=self.RED_COLOR, alpha=0.7, 
                         label='Both')           # Đã ngắn gọn
        ]

    def add_legend(self, ax: Axes):
        """Add a legend to the plot"""
        if self.has_any_anomaly:
            # Create legend elements
            legend_elements = self.create_legend_elements()

            # Add legend in the best location that doesn't overlap with the plot
            ax.legend(handles=legend_elements, 
                     loc='center left',    # You can adjust this location
                     bbox_to_anchor=(1.02, 0.5),  # Place legend outside the plot
                     fontsize=8,
                     title='Anomalies',
                     title_fontsize=9,
                     framealpha=0.8,
                     edgecolor='gray')

            # Adjust layout to make room for legend
            ax.figure.tight_layout() 