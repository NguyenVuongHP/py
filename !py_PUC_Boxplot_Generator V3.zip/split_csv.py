import os
import pandas as pd
import sys
from PyQt6.QtWidgets import (QApplication, QMainWindow, QTextEdit, QMessageBox, QInputDialog,
                             QPushButton, QVBoxLayout, QLabel, QFileDialog, QWidget)
from PyQt6.QtCore import QTime, Qt, QUrl
from PyQt6.QtGui import QDesktopServices, QFont, QColor, QPalette

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle("CSV Splitter")
        self.resize(450, 350)
        
        # Set color palette
        palette = QPalette()
        palette.setColor(QPalette.ColorRole.Window, QColor(44, 62, 80))
        palette.setColor(QPalette.ColorRole.WindowText, Qt.GlobalColor.white)
        palette.setColor(QPalette.ColorRole.Base, QColor(52, 73, 94))
        palette.setColor(QPalette.ColorRole.Text, Qt.GlobalColor.white)
        palette.setColor(QPalette.ColorRole.Button, QColor(41, 128, 185))
        palette.setColor(QPalette.ColorRole.ButtonText, Qt.GlobalColor.white)
        palette.setColor(QPalette.ColorRole.Highlight, QColor(231, 76, 60))
        palette.setColor(QPalette.ColorRole.HighlightedText, Qt.GlobalColor.white)
        self.setPalette(palette)

        main_layout = QVBoxLayout()
        main_layout.setSpacing(15)

        # Title
        title_label = QLabel("CSV Splitter", self)
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title_label.setFont(QFont("Arial", 20, QFont.Weight.Bold))
        title_label.setStyleSheet("color: #e74c3c;")
        main_layout.addWidget(title_label)

        # Select CSV file button
        self.select_file_btn = QPushButton("📄 Select CSV", self)
        self.select_file_btn.clicked.connect(self.select_file)
        self.select_file_btn.setStyleSheet("""
            QPushButton {
                background-color: #2980b9;
                color: white;
                border-radius: 5px;
                font-weight: bold;
                padding: 8px;
            }
            QPushButton:hover {
                background-color: #1f618d;
            }
        """)
        main_layout.addWidget(self.select_file_btn)

        # Log area
        log_label = QLabel("Processing Log:", self)
        log_label.setFont(QFont("Arial", 12, QFont.Weight.Bold))
        log_label.setStyleSheet("color: #f1c40f;")
        main_layout.addWidget(log_label)

        self.log_area = QTextEdit(self)
        self.log_area.setReadOnly(True)
        self.log_area.setStyleSheet("""
            QTextEdit {
                background-color: #34495e;
                color: #ecf0f1;
                border: 1px solid #2c3e50;
                border-radius: 5px;
                font-size: 10pt;
            }
        """)
        main_layout.addWidget(self.log_area)

        # Author name
        author_label = QLabel("Author: nguyenvanvuong1", self)
        author_label.setAlignment(Qt.AlignmentFlag.AlignRight)
        author_label.setStyleSheet("color: #bdc3c7; font-style: italic; font-size: 9pt;")
        main_layout.addWidget(author_label)

        central_widget = QWidget()
        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)

    def select_file(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Select CSV File", "", "CSV Files (*.csv)")
        if file_path:
            self.process_file(file_path)

    def process_file(self, file_path):
        DATA_SPLIT_BY_COLUMNNAME, ok_clicked = QInputDialog.getText(None, "Enter Column", "Enter column name to split CSV data:")
        if not ok_clicked or DATA_SPLIT_BY_COLUMNNAME == "":
            return

        self.update_log(f"Reading file: {os.path.basename(file_path)}")
        header_rows = pd.read_csv(file_path, nrows=2)
        filedata = pd.read_csv(file_path, index_col=None, sep=',', header=0)

        if filedata.empty:
            self.update_log("File is empty")
            return

        if DATA_SPLIT_BY_COLUMNNAME not in filedata.columns:
            self.update_log(f"Column '{DATA_SPLIT_BY_COLUMNNAME}' not found")
            return

        output_dir = os.path.dirname(file_path)

        group_data = filedata.groupby(by=DATA_SPLIT_BY_COLUMNNAME, sort=None)
        for chunk_name, chunk_data in group_data:
            output_filename = os.path.join(output_dir, f"{chunk_name}.csv")
            final_data = pd.concat([header_rows, chunk_data], ignore_index=True)
            final_data = final_data.drop_duplicates()
            final_data.to_csv(output_filename, header=True, index=False, sep=",")
            self.update_log(f"Exported {chunk_name}.csv")

        self.show_message_box("Success", f"Processed file: {os.path.basename(file_path)} \nExported to: {output_dir}")

    def update_log(self, text):
        current_time = QTime.currentTime().toString()
        self.log_area.append(f"{current_time}: {text}")
        self.log_area.repaint()

    def show_message_box(self, title, message):
        QMessageBox.information(self, title, message)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    main_window = MainWindow()
    main_window.show()
    sys.exit(app.exec())
